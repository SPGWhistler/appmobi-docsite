//use this to make an HTML element pulse by altering its opacity style 

var pulseTimeout;
var pulseVal = 1;
var pulseDown = true;
function pulseElement(obj) {
	if (obj != null) {
		if (pulseDown == true) {
			pulseVal = pulseVal - 0.1;
		} else { pulseVal = pulseVal + 0.1; }
		if (pulseVal <= 0) { pulseDown = false; pulseVal = 0;}
		if (pulseVal >= 1) { pulseDown = true; pulseVal = 1; }
				
		obj.style.opacity = pulseVal;
		pulseTimeout = setTimeout(function(){pulseElement(obj)},80);
	
	} else { clearTimeout(pulseTimeout); }
}