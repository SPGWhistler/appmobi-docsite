//An object to handle drag and drop of HTML elements on the screen
//This object REQUIRES jqmobi.js and jq.css3animate.js

//initialize the object wtih the following format
/*

var myDragDropObject = new objDragDrop({
[HTML Element ID]:{x:[x-coordinate position],y:[y-coordinate position]}
});

*/

function objDragDrop(objDraggableElements) {

	//This all runs when the object is initiated
	this.selectedElement = "";
	this.iClickOffsetX = 0;
	this.iClickOffsetY = 0;
	var boolInDropArea = "";
	this.selectedProductID = "";
	

	for (itm in objDraggableElements) {
		$("#" + itm).css("position","absolute");
		objPosition = {x:eval(objDraggableElements[itm].x),y:eval(objDraggableElements[itm].y),previous:false}
		$("#" + itm).css3Animate(objPosition);		
	}
	
	document.addEventListener("touchstart",function(evt){

		try {
			//objSelectEvent=evt;
			this.iClickOffsetX = evt.touches[0].pageX - objItems[evt.srcElement.id].x;
			this.iClickOffsetY = evt.touches[0].pageY - objItems[evt.srcElement.id].y;
			this.selectedElement = evt.srcElement.id;
			this.selectedProductID = evt.srcElement.getAttribute("itemid");
			//console.log(this.selectedProductID);
			
			for (itm in objDraggableElements) {
				$("#" + itm).css("zIndex",0);
			}
			$("#" + this.selectedElement).css("zIndex",999);
			$("#" + this.selectedElement).css("webkitTransition","");  //to defeat slowness triggered by using the timing functions
			
		} 
		catch(e) 
		{ 
			//console.log(e); 
		}
	
	}, false);
	
	document.addEventListener("touchmove",function(evt){
	
		if (this.selectedElement != "") {
			var xPos = evt.touches[0].pageX - this.iClickOffsetX;
			var yPos = evt.touches[0].pageY - this.iClickOffsetY;	
			
			//we have a selected element
			$("#" + this.selectedElement).css3Animate({x:xPos,y:yPos});
			
			testDropAreas(xPos,yPos);

		}
		
	}, false);
	
	document.addEventListener("touchend",function(evt){
	
		if (this.selectedElement != "") {
		
			//animate the item back to its home position
			objPosition = {x:eval("objItems." + this.selectedElement + ".x"),y:eval("objItems." + this.selectedElement + ".y"),time:300,previous:false,callback:function(){
				$("#" + this.selectedElement).css3Animate({x:eval(objDraggableElements[itm].x),y:eval(objDraggableElements[itm].y),previous:false});
			}}
			
			$("#" + this.selectedElement).css3Animate(objPosition);
			
			if (boolInDropArea == true) {
				boolInDropArea = false;
				//console.log("something was purchased: " + eval("objSalesItems." + this.selectedProductID + ".name"));
				oneTouchPurchase(this.selectedProductID);
			}
			
			this.selectedProductID = "";
			this.selectedElement = "";
			
			//turn off mouse over events
			document.getElementById("purchaseDisplay").style.display="none";
			

		}	
	}, false);
	
	//pass the current touch position to determine whether the dragged item is in a drop area or not
	var testDropAreas = function(xPos,yPos) {
		try {
		
			if (xPos > 320 && xPos < 520 && yPos > 500 && yPos < 800) {
				//console.log(xPos + "," + yPos);
				document.getElementById("purchaseDisplay").style.display="block";
				boolInDropArea = true;
			} else  {
				document.getElementById("purchaseDisplay").style.display="none";
				boolInDropArea = false;
			}	
		} catch(e) {}
	}
}

